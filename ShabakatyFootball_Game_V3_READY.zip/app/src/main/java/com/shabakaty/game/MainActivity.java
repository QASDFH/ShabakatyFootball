
package com.shabakaty.game;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.view.*;
import java.util.*;

public class MainActivity extends Activity {
 public void onCreate(Bundle b){super.onCreate(b);getWindow().setFlags(1024,1024);setContentView(new GameView());}

 class GameView extends View {
  Paint p=new Paint(1); float W,H; float bx=.5f,by=.5f,bvx=0,bvy=0;
  float playerX=.25f,playerY=.5f; int a=0,d=0; boolean pass=false,shoot=false;
  ArrayList<P> blue=new ArrayList<>(), red=new ArrayList<>();
  class P{float x,y;boolean g;P(float X,float Y,boolean G){x=X;y=Y;g=G;}}
  GameView(){super(MainActivity.this); p.setTypeface(Typeface.DEFAULT_BOLD);
   blue.add(new P(.07f,.5f,true)); red.add(new P(.93f,.5f,true));
   float[][] pos={{.20f,.25f},{.20f,.5f},{.20f,.75f},{.32f,.18f},{.32f,.38f},{.32f,.62f},{.32f,.82f},{.43f,.3f},{.43f,.7f},{.47f,.5f}};
   for(float[] q:pos)blue.add(new P(q[0],q[1],false));
   for(float[] q:pos)red.add(new P(1-q[0],q[1],false));
  }
  protected void onDraw(Canvas c){W=getWidth();H=getHeight();
   p.setStyle(Paint.Style.FILL);
   for(int i=0;i<10;i++){p.setColor(i%2==0?Color.rgb(32,132,52):Color.rgb(28,120,47));c.drawRect(i*W/10,0,(i+1)*W/10,H,p);}
   p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(5);p.setColor(Color.WHITE);
   c.drawRect(18,18,W-18,H-18,p);c.drawLine(W/2,18,W/2,H-18,p);c.drawCircle(W/2,H/2,H*.16f,p);
   c.drawRect(18,H*.32f,W*.16f,H*.68f,p);c.drawRect(W-W*.16f,H*.32f,W-18,H*.68f,p);
   p.setStyle(Paint.Style.FILL);
   for(P q:blue) drawP(c,q,Color.rgb(30,105,235)); for(P q:red) drawP(c,q,Color.rgb(220,45,50));
   p.setColor(Color.WHITE);c.drawCircle(bx*W,by*H,12,p);
   p.setColor(Color.argb(200,0,0,0));c.drawRoundRect(W*.36f,8,W*.64f,58,18,18,p);
   p.setColor(Color.WHITE);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(25);c.drawText("شبكتي ⚽  "+a+" - "+d,W/2,42,p);
   // virtual joystick
   p.setColor(Color.argb(80,255,255,255));c.drawCircle(105,H-105,70,p);c.drawCircle(W-95,H-95,55,p);c.drawCircle(W-185,H-175,48,p);
   p.setColor(Color.WHITE);p.setTextSize(28);c.drawText("◀",72,H-96,p);c.drawText("▶",120,H-96,p);
   c.drawText("⚽",W-113,H-87,p);c.drawText("↑",W-198,H-165,p);
  }
  void drawP(Canvas c,P q,int col){float x=q.x*W,y=q.y*H;p.setColor(col);c.drawCircle(x,y,17,p);p.setColor(Color.WHITE);c.drawCircle(x,y-4,7,p);if(q.g){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);c.drawCircle(x,y,22,p);p.setStyle(Paint.Style.FILL);}}
  public boolean onTouchEvent(MotionEvent e){float x=e.getX(),y=e.getY();int ac=e.getAction();
   if(ac==0||ac==2){
    if(x<180&&y>H-190){if(x<90)playerX-=.012f;else playerX+=.012f;}
    else if(x>W-250&&x<W-125&&y>H-235){playerY-=.012f;}
    else if(x>W-150&&y>H-175){shoot=true;}
    else if(x>W-250&&x<W-125&&y>H-130){pass=true;}
   } else if(ac==1){shoot=false;pass=false;} return true;
  }
  void update(){
   playerX=Math.max(.10f,Math.min(.65f,playerX));playerY=Math.max(.10f,Math.min(.90f,playerY));
   if(shoot){bvx=.018f;bvy=(playerY-by)*.035f;}
   else if(pass){bvx=(playerX-bx)*.018f;bvy=(playerY-by)*.018f;}
   bx+=bvx;by+=bvy;bvx*=.985f;bvy*=.985f;
   if(by<.04||by>.96)bvy=-bvy*.75f;
   if(bx>.98){a++;reset();} if(bx<.02){d++;reset();}
   // AI pressure toward ball
   for(P q:red) if(!q.g){q.x+=(bx-q.x)*.006f;q.y+=(by-q.y)*.006f;}
   for(P q:blue) if(!q.g){q.x+=(Math.max(.12f,bx-.10f)-q.x)*.002f;q.y+=(by-q.y)*.002f;}
   invalidate();
  }
  void reset(){bx=.5f;by=.5f;bvx=bvy=0;}
  Runnable r=()->{update();postDelayed(r,16);};
  protected void onAttachedToWindow(){super.onAttachedToWindow();post(r);}
 }
}
