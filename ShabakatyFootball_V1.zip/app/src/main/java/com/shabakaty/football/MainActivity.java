package com.shabakaty.football;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.view.*;
import android.content.Context;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(1024,1024);
        setContentView(new FootballView(this));
    }

    static class FootballView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float px, py, bx, by, vx, vy;
        float opponentX, opponentY;
        float stickX, stickY;
        boolean dragging = false;
        int myScore = 0, oppScore = 0;
        long start = System.currentTimeMillis();

        FootballView(Context c) {
            super(c);
            p.setTypeface(Typeface.create("sans", Typeface.BOLD));
            setFocusable(true);
        }

        void reset() {
            px = getWidth()*0.25f; py = getHeight()*0.50f;
            opponentX = getWidth()*0.75f; opponentY = getHeight()*0.50f;
            bx = getWidth()*0.50f; by = getHeight()*0.50f;
            vx = vy = 0;
        }

        @Override protected void onSizeChanged(int w,int h,int ow,int oh) { reset(); }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            int w=getWidth(), h=getHeight();
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.rgb(25,125,55)); c.drawRect(0,0,w,h,p);

            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5); p.setColor(Color.WHITE);
            c.drawRect(18,18,w-18,h-18,p);
            c.drawLine(w/2f,18,w/2f,h-18,p);
            c.drawCircle(w/2f,h/2f,65,p);
            c.drawRect(18,h/2f-120,110,h/2f+120,p);
            c.drawRect(w-110,h/2f-120,w-18,h/2f+120,p);
            p.setStyle(Paint.Style.FILL);

            drawCircle(c, px,py,28,Color.rgb(40,120,220));
            drawCircle(c, opponentX,opponentY,28,Color.rgb(220,50,50));
            drawCircle(c,bx,by,15,Color.WHITE);

            // score
            p.setColor(Color.WHITE); p.setTextSize(34); p.setTextAlign(Paint.Align.CENTER);
            c.drawText(myScore+"  -  "+oppScore,w/2f,55,p);

            // control pad
            p.setColor(0x66999999); c.drawCircle(100,h-100,70,p);
            p.setColor(0x99FFFFFF); c.drawCircle(dragging?stickX:100,dragging?stickY:h-100,28,p);

            // shoot button
            p.setColor(0xAAFFFFFF); c.drawCircle(w-100,h-100,65,p);
            p.setColor(Color.DKGRAY); p.setTextSize(24); c.drawText("SHOOT",w-100,h-92,p);

            long elapsed=(System.currentTimeMillis()-start)/1000;
            long remain=Math.max(0,90-elapsed);
            p.setColor(Color.WHITE); p.setTextSize(22);
            c.drawText(String.format(Locale.US,"%02d:%02d",remain/60,remain%60),w/2f,85,p);

            update();
            postInvalidateDelayed(16);
        }

        void drawCircle(Canvas c,float x,float y,float r,int color) {
            p.setColor(color); p.setStyle(Paint.Style.FILL); c.drawCircle(x,y,r,p);
        }

        void update() {
            if(getWidth()==0) return;
            float speed=5f;
            if(dragging) {
                px += (stickX-100)/70f*speed;
                py += (stickY-(getHeight()-100))/70f*speed;
            }
            px=Math.max(45,Math.min(getWidth()-45,px));
            py=Math.max(45,Math.min(getHeight()-45,py));

            bx += vx; by += vy;
            vx*=0.96f; vy*=0.96f;
            if(bx<25 || bx>getWidth()-25) vx=-vx;
            if(by<25 || by>getHeight()-25) vy=-vy;
            if(Math.hypot(px-bx,py-by)<43 && Math.abs(vx)+Math.abs(vy)<1.5) {
                bx += (bx-px)/43f*3; by += (by-py)/43f*3;
            }
            if(bx<10) { oppScore++; reset(); }
            if(bx>getWidth()-10) { myScore++; reset(); }
        }

        @Override public boolean onTouchEvent(android.view.MotionEvent e) {
            float x=e.getX(), y=e.getY();
            if(e.getAction()==MotionEvent.ACTION_DOWN || e.getAction()==MotionEvent.ACTION_MOVE) {
                if(Math.hypot(x-100,y-(getHeight()-100))<95) {
                    dragging=true; stickX=x; stickY=y;
                } else if(Math.hypot(x-(getWidth()-100),y-(getHeight()-100))<90
                        && e.getAction()==MotionEvent.ACTION_DOWN) {
                    float dx=bx-px, dy=by-py, d=(float)Math.max(1,Math.hypot(dx,dy));
                    if(d<150) { vx=dx/d*14; vy=dy/d*14; }
                }
            } else if(e.getAction()==MotionEvent.ACTION_UP || e.getAction()==MotionEvent.ACTION_CANCEL) {
                dragging=false;
            }
            return true;
        }
    }
}