
package com.shabakaty.game;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import java.util.*;

public class MainActivity extends Activity {
    public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(new GameView());
    }

    class Player { float x,y; Player(float X,float Y){x=X;y=Y;} }

    class GameView extends View {
        Paint p=new Paint(1);
        ArrayList<Player> blue=new ArrayList<>(), red=new ArrayList<>();
        float W,H,bx=.5f,by=.5f,bvx=0,bvy=0,ux=.30f,uy=.50f;
        int home=0,away=0,seconds=90;
        boolean left,right,up,down,pass,shoot;
        long last=System.currentTimeMillis();

        GameView(){
            super(MainActivity.this);
            float[][] f={{.12f,.22f},{.12f,.40f},{.12f,.60f},{.12f,.78f},
                         {.27f,.20f},{.27f,.40f},{.27f,.60f},{.27f,.80f},
                         {.40f,.34f},{.40f,.66f},{.055f,.50f}};
            for(float[] q:f)blue.add(new Player(q[0],q[1]));
            for(float[] q:f)red.add(new Player(1-q[0],q[1]));
        }

        protected void onDraw(Canvas c){
            W=getWidth();H=getHeight();
            p.setStyle(Paint.Style.FILL);
            for(int i=0;i<10;i++){
                p.setColor(i%2==0?Color.rgb(30,130,50):Color.rgb(25,118,45));
                c.drawRect(i*W/10,0,(i+1)*W/10,H,p);
            }
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(5);p.setColor(Color.WHITE);
            c.drawRect(18,18,W-18,H-18,p);c.drawLine(W/2,18,W/2,H-18,p);
            c.drawCircle(W/2,H/2,H*.15f,p);
            c.drawRect(18,H*.31f,W*.15f,H*.69f,p);
            c.drawRect(W*.85f,H*.31f,W-18,H*.69f,p);
            p.setStyle(Paint.Style.FILL);
            drawTeam(c,blue,Color.rgb(35,100,225));
            drawTeam(c,red,Color.rgb(220,45,45));
            p.setColor(Color.WHITE);c.drawCircle(bx*W,by*H,12,p);

            p.setColor(Color.argb(210,0,0,0));c.drawRoundRect(W*.33f,7,W*.67f,62,18,18,p);
            p.setColor(Color.WHITE);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(24);
            c.drawText("شبكتي ⚽   "+home+" - "+away+"   "+seconds+"s",W/2,42,p);

            p.setColor(Color.argb(100,255,255,255));
            c.drawCircle(100,H-100,70,p);
            c.drawCircle(W-100,H-95,60,p);
            c.drawCircle(W-200,H-180,50,p);
            c.drawCircle(W-285,H-115,48,p);
            p.setColor(Color.WHITE);p.setTextSize(25);
            c.drawText("◀",65,H-92,p);c.drawText("▶",115,H-92,p);
            c.drawText("↑",W-214,H-170,p);c.drawText("⚽",W-120,H-87,p);c.drawText("P",W-300,H-105,p);
        }

        void drawTeam(Canvas c,ArrayList<Player> t,int col){
            for(int i=0;i<t.size();i++){
                Player q=t.get(i);
                p.setColor(col);c.drawCircle(q.x*W,q.y*H,i==t.size()-1?21:17,p);
                p.setColor(Color.WHITE);c.drawCircle(q.x*W,q.y*H-4,6,p);
            }
        }

        public boolean onTouchEvent(MotionEvent e){
            float x=e.getX(),y=e.getY();
            if(e.getAction()==MotionEvent.ACTION_DOWN||e.getAction()==MotionEvent.ACTION_MOVE){
                left=x<145&&y>H-185;
                right=x>=85&&x<180&&y>H-185;
                up=x>W-245&&x<W-145&&y>H-235;
                down=x>W-245&&x<W-145&&y<=H-120&&y>H-190;
                pass=x>W-325&&x<W-235&&y>H-170;
                shoot=x>W-160&&y>H-175;
            } else if(e.getAction()==MotionEvent.ACTION_UP) {
                left=right=up=down=pass=shoot=false;
            }
            return true;
        }

        void update(){
            if(left)ux-=.008f;if(right)ux+=.008f;if(up)uy-=.008f;if(down)uy+=.008f;
            ux=Math.max(.08f,Math.min(.72f,ux));uy=Math.max(.08f,Math.min(.92f,uy));
            blue.get(9).x=ux;blue.get(9).y=uy;

            float dist=(float)Math.hypot(bx-ux,by-uy);
            if(dist<.10f&&shoot){bvx=.020f;bvy=(by-uy)*.12f;}
            if(dist<.10f&&pass){bvx=.011f;bvy=(by-uy)*.08f;}

            bx+=bvx;by+=bvy;bvx*=.986f;bvy*=.986f;
            if(by<.04f||by>.96f)bvy=-bvy*.75f;

            // opponent AI: chase ball, but goalkeeper stays near goal
            for(int i=0;i<red.size()-1;i++){
                Player q=red.get(i);q.x+=(bx-q.x)*.0045f;q.y+=(by-q.y)*.0045f;
            }
            Player keeper=red.get(red.size()-1);
            keeper.y+=(by-keeper.y)*.02f;
            keeper.y=Math.max(.36f,Math.min(.64f,keeper.y));

            if(bx>.985f){home++;reset();}
            if(bx<.015f){away++;reset();}

            long now=System.currentTimeMillis();
            if(now-last>=1000){seconds--;last=now;if(seconds<=0)seconds=90;}
            invalidate();
        }

        void reset(){bx=.5f;by=.5f;bvx=bvy=0;}

        Runnable loop=new Runnable(){public void run(){update();postDelayed(this,16);}};
        protected void onAttachedToWindow(){super.onAttachedToWindow();post(loop);}
    }
}
