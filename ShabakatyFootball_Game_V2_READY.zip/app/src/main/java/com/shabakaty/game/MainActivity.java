
package com.shabakaty.game;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(new GameView());
    }

    class GameView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float bx=0, by=0, vx=0, vy=0;
        float px=0, py=0;
        boolean left,right,up,down,kick;
        int scoreA=0, scoreB=0;
        ArrayList<Player> blue = new ArrayList<>();
        ArrayList<Player> red = new ArrayList<>();
        Random rnd = new Random();

        class Player {
            float x,y,dx,dy;
            boolean keeper;
            Player(float x,float y,boolean k){this.x=x;this.y=y;keeper=k;}
        }

        GameView() {
            super(MainActivity.this);
            p.setTypeface(Typeface.create("sans",Typeface.BOLD));
            for(int i=0;i<10;i++) blue.add(new Player(.18f+(i%5)*.10f,.25f+(i/5)*.30f,false));
            for(int i=0;i<10;i++) red.add(new Player(.82f-(i%5)*.10f,.25f+(i/5)*.30f,false));
            blue.add(new Player(.06f,.50f,true));
            red.add(new Player(.94f,.50f,true));
        }

        protected void onDraw(Canvas c) {
            super.onDraw(c);
            float W=getWidth(), H=getHeight();
            p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(28,125,48)); c.drawRect(0,0,W,H,p);

            // pitch stripes
            for(int i=0;i<10;i++){
                p.setColor(i%2==0?Color.rgb(31,135,52):Color.rgb(27,125,47));
                c.drawRect(i*W/10f,0,(i+1)*W/10f,H,p);
            }

            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5); p.setColor(Color.WHITE);
            c.drawRect(22,22,W-22,H-22,p);
            c.drawLine(W/2,22,W/2,H-22,p);
            c.drawCircle(W/2,H/2,Math.min(W,H)*.13f,p);
            c.drawCircle(W/2,H/2,5,p);

            float boxH=H*.34f, boxW=W*.14f;
            c.drawRect(22,(H-boxH)/2,22+boxW,(H+boxH)/2,p);
            c.drawRect(W-22-boxW,(H-boxH)/2,W-22,(H+boxH)/2,p);
            p.setStyle(Paint.Style.FILL);

            // goals
            p.setColor(Color.WHITE);
            c.drawRect(0,H*.43f,22,H*.57f,p);
            c.drawRect(W-22,H*.43f,W,H*.57f,p);

            for(Player q:blue) drawPlayer(c,q,Color.rgb(35,100,230));
            for(Player q:red) drawPlayer(c,q,Color.rgb(220,45,45));

            p.setColor(Color.WHITE);
            c.drawCircle(bx*W,by*H,13,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(Color.BLACK);
            c.drawCircle(bx*W,by*H,13,p); p.setStyle(Paint.Style.FILL);

            // scoreboard
            p.setColor(Color.argb(190,0,0,0)); c.drawRoundRect(W*.35f,8,W*.65f,55,18,18,p);
            p.setColor(Color.WHITE); p.setTextSize(25);
            p.setTextAlign(Paint.Align.CENTER);
            c.drawText("شبكتي ⚽   "+scoreA+" - "+scoreB, W/2,40,p);

            // controls
            p.setColor(Color.argb(85,255,255,255));
            c.drawCircle(95,H-95,62,p);
            c.drawCircle(W-95,H-95,62,p);
            c.drawCircle(W-185,H-165,45,p);
            p.setColor(Color.WHITE); p.setTextSize(25);
            c.drawText("◀",65,H-87,p); c.drawText("▶",113,H-87,p);
            c.drawText("⚽",W-112,H-86,p); c.drawText("↑",W-197,H-155,p);
        }

        void drawPlayer(Canvas c, Player q, int color){
            float x=q.x*getWidth(), y=q.y*getHeight();
            p.setColor(color); c.drawCircle(x,y,18,p);
            p.setColor(Color.WHITE); c.drawCircle(x,y-5,7,p);
            if(q.keeper){
                p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3);
                c.drawCircle(x,y,22,p); p.setStyle(Paint.Style.FILL);
            }
        }

        void resetBall(){
            bx=.5f; by=.5f; vx=0; vy=0;
        }

        protected void onSizeChanged(int w,int h,int ow,int oh){ resetBall(); }

        public boolean onTouchEvent(android.view.MotionEvent e){
            float x=e.getX(), y=e.getY(), W=getWidth(), H=getHeight();
            if(e.getAction()==MotionEvent.ACTION_DOWN || e.getAction()==MotionEvent.ACTION_MOVE){
                left = x<170 && y>H-180 && x<130;
                right = x<180 && x>70 && y>H-180;
                kick = x>W-150 && y>H-180;
                up = x>W-240 && x<W-135 && y>H-220;
                if(x<W*.45f && y<H-180) { px=x/W; py=y/H; }
            } else if(e.getAction()==MotionEvent.ACTION_UP){
                left=right=up=down=kick=false;
            }
            return true;
        }

        void update(){
            float s=.0028f;
            if(left) bx-=s;
            if(right) bx+=s;
            if(up) by-=s;
            if(kick){
                vx=.012f; vy=(by-.5f)*.02f;
            }
            bx+=vx; by+=vy; vx*=.985f; vy*=.985f;

            if(by<.05f){by=.05f;vy=-vy*.7f;}
            if(by>.95f){by=.95f;vy=-vy*.7f;}
            if(bx<.02f){ scoreB++; resetBall(); }
            if(bx>.98f){ scoreA++; resetBall(); }

            for(Player q:blue) follow(q,bx,by,true);
            for(Player q:red) follow(q,bx,by,false);
            invalidate();
        }

        void follow(Player q,float tx,float ty,boolean own){
            if(q.keeper) return;
            float targetX = tx + (own ? -.08f : .08f);
            float targetY = ty;
            q.x += Math.max(-.003f,Math.min(.003f,targetX-q.x));
            q.y += Math.max(-.003f,Math.min(.003f,targetY-q.y));
            q.x=Math.max(.08f,Math.min(.92f,q.x));
            q.y=Math.max(.08f,Math.min(.92f,q.y));
        }

        Runnable loop = new Runnable(){ public void run(){ update(); postDelayed(this,16); }};
        protected void onAttachedToWindow(){ super.onAttachedToWindow(); post(loop); }
    }
}
