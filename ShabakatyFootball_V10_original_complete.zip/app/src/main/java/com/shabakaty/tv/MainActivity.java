package com.shabakaty.tv;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class MainActivity extends Activity {
    EditText token;
    LinearLayout list;
    TextView count, status;
    String base = "https://api.football-data.org/v4/matches";
    android.content.SharedPreferences prefs;

    int green = Color.rgb(32,199,119);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        buildUi();
        token.setText(prefs.getString("token",""));
    }

    TextView tv(String s, int sp) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(sp);
        t.setPadding(16,10,16,10);
        return t;
    }

    Button btn(String s) {
        Button b = new Button(this); b.setText(s); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setTextSize(15); return b;
    }

    void buildUi() {
        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL); main.setPadding(14,10,14,10);
        main.setBackgroundColor(Color.rgb(4,8,6));

        TextView title = tv("⚽ شبكتي V10", 24);
        title.setGravity(Gravity.CENTER);
        main.addView(title);

        token = new EditText(this);
        token.setHint("الصق مفتاح الدخول هنا");
        token.setHintTextColor(Color.GRAY); token.setTextColor(Color.WHITE);
        token.setSingleLine(true); token.setInputType(0x00000081);
        main.addView(token, new LinearLayout.LayoutParams(-1,55));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button save = btn("حفظ المفتاح");
        Button today = btn("اليوم");
        Button tomorrow = btn("غداً");
        Button live = btn("🔴 مباشر");
        row.addView(save, new LinearLayout.LayoutParams(0,60,1));
        row.addView(today, new LinearLayout.LayoutParams(0,60,1));
        row.addView(tomorrow, new LinearLayout.LayoutParams(0,60,1));
        row.addView(live, new LinearLayout.LayoutParams(0,60,1));
        main.addView(row);

        status = tv("جاهز", 14); status.setTextColor(green);
        main.addView(status);
        count = tv("المباريات: 0", 17);
        count.setGravity(Gravity.RIGHT);
        main.addView(count);

        ScrollView sv = new ScrollView(this);
        list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        sv.addView(list); main.addView(sv, new LinearLayout.LayoutParams(-1,0,1));

        TextView foot = tv("Football data provided by the Football-Data.org API", 11);
        foot.setTextColor(Color.GRAY); foot.setGravity(Gravity.CENTER);
        main.addView(foot);

        save.setOnClickListener(v -> {
            prefs.edit().putString("token", token.getText().toString().trim()).apply();
            status.setText("تم حفظ المفتاح");
            loadDay(0);
        });
        today.setOnClickListener(v -> loadDay(0));
        tomorrow.setOnClickListener(v -> loadDay(1));
        live.setOnClickListener(v -> loadLive());

        setContentView(main);
    }

    String key() { return token.getText().toString().trim(); }

    void loadDay(int offset) {
        if (key().isEmpty()) { status.setText("أدخل المفتاح أولاً"); return; }
        LocalDate d = LocalDate.now().plusDays(offset);
        status.setText("جاري تحميل مباريات " + (offset==0 ? "اليوم" : "غداً") + "...");
        request(base + "?dateFrom=" + d + "&dateTo=" + d);
    }

    void loadLive() {
        if (key().isEmpty()) { status.setText("أدخل المفتاح أولاً"); return; }
        status.setText("جاري تحميل المباريات المباشرة...");
        request(base + "?status=LIVE");
    }

    void request(String url) {
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection)new URL(url).openConnection();
                c.setRequestMethod("GET"); c.setConnectTimeout(12000); c.setReadTimeout(15000);
                c.setRequestProperty("X-Auth-Token", key());
                int code = c.getResponseCode();
                InputStream in = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
                BufferedReader r = new BufferedReader(new InputStreamReader(in));
                StringBuilder sb = new StringBuilder(); String line;
                while((line=r.readLine())!=null) sb.append(line);
                r.close();
                final String data = sb.toString(); final int statusCode = code;
                runOnUiThread(() -> showResults(data,statusCode));
            } catch(Exception e) {
                runOnUiThread(() -> {
                    status.setText("تعذر الاتصال بالإنترنت");
                    count.setText("المباريات: 0");
                });
            }
        }).start();
    }

    void showResults(String data, int code) {
        list.removeAllViews();
        if(code != 200) {
            status.setText("خطأ من الخادم: " + code);
            TextView e = tv(data.length()>250 ? data.substring(0,250) : data, 14);
            list.addView(e); return;
        }
        try {
            JSONObject root = new JSONObject(data);
            JSONArray arr = root.optJSONArray("matches");
            int n = arr == null ? 0 : arr.length();
            count.setText("المباريات: " + n);
            status.setText(n == 0 ? "لا توجد مباريات في هذا الاختيار" : "تم التحديث ✓");
            if(arr == null) return;

            DateTimeFormatter out = DateTimeFormatter.ofPattern("HH:mm");
            for(int i=0;i<arr.length();i++) {
                JSONObject m=arr.getJSONObject(i);
                JSONObject home=m.optJSONObject("homeTeam"), away=m.optJSONObject("awayTeam");
                JSONObject comp=m.optJSONObject("competition"), score=m.optJSONObject("score");
                String hn=home==null?"-":home.optString("name","-");
                String an=away==null?"-":away.optString("name","-");
                String cn=comp==null?"":comp.optString("name","");
                String st=m.optString("status","");
                String dt=m.optString("utcDate","");
                String time=dt.length()>=16?dt.substring(11,16):"";
                String hs="-", as="-";
                if(score!=null){
                    JSONObject full=score.optJSONObject("fullTime");
                    if(full!=null){ hs=full.isNull("home")?"-":String.valueOf(full.optInt("home")); as=full.isNull("away")?"-":String.valueOf(full.optInt("away")); }
                }
                String label = statusArabic(st);
                TextView card=tv(hn+"   "+hs+"  -  "+as+"   "+an+"\n"+cn+"   •   "+time+" UTC   •   "+label,16);
                card.setBackgroundColor(Color.rgb(18,25,21));
                card.setPadding(18,18,18,18);
                LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT);
                p.setMargins(0,6,0,6); list.addView(card,p);
            }
        } catch(Exception e) {
            status.setText("تعذر قراءة بيانات المباريات");
        }
    }

    String statusArabic(String s) {
        if("FINISHED".equals(s)) return "منتهية";
        if("IN_PLAY".equals(s)) return "جارية";
        if("PAUSED".equals(s)) return "استراحة";
        if("POSTPONED".equals(s)) return "مؤجلة";
        if("CANCELLED".equals(s)) return "ملغاة";
        if("SUSPENDED".equals(s)) return "متوقفة";
        return "قادمة";
    }
}
