package com.shabakaty.game;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(new FootballView());
    }

    static class Player {
        float x,y;
        Player(float x,float y){this.x=x;this.y=y;}
    }

    class FootballView extends View {
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        ArrayList<Player> blue=new ArrayList<>(), red=new ArrayList<>();
        float ballX=.5f, ballY=.5f, ballVX=0, ballVY=0;
        float userX=.22f,userY=.50f;
        int home=0,away=0;
        boolean l,r,u,d,kick,pass;

        FootballView(){
            super(MainActivity.this);
            float[][] a={{.18f,.22f},{.18f,.40f},{.18f,.60f},{.18f,.78f},
                         {.32f,.18f},{.32f,.38f},{.32f,.62f},{.32f,.82f},
                         {.43f,.35f},{.43f,.65f}};
            for(float[] q:a){blue.add(new Player(q[0],q[1])); red.add(new Player(1-q[0],q[1]));}
            blue.add(new Player(.06f,.50f)); red.add(new Player(.94f,.50f));
        }

        @Override protected void onDraw(Canvas c){
            float W=getWidth(),H=getHeight();
            for(int i=0;i<10;i++){
                p.setStyle(Paint.Style.FILL);
                p.setColor(i%2==0?Color.rgb(30,130,50):Color.rgb(25,118,45));
                c.drawRect(i*W/10,0,(i+1)*W/10,H,p);
            }
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(5);p.setColor(Color.WHITE);
            c.drawRect(20,20,W-20,H-20,p);
            c.drawLine(W/2,20,W/2,H-20,p);
            c.drawCircle(W/2,H/2,Math.min(W,H)*.15f,p);
            c.drawRect(20,H*.32f,W*.16f,H*.68f,p);
            c.drawRect(W*.84f,H*.32f,W-20,H*.68f,p);
            p.setStyle(Paint.Style.FILL);
            drawTeam(c,blue,Color.rgb(35,100,225));
            drawTeam(c,red,Color.rgb(220,45,45));
            p.setColor(Color.WHITE);c.drawCircle(ballX*W,ballY*H,12,p);
            p.setColor(Color.argb(200,0,0,0));c.drawRoundRect(W*.36f,8,W*.64f,58,16,16,p);
            p.setColor(Color.WHITE);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(24);
            c.drawText("شبكتي ⚽   "+home+" - "+away,W/2,41,p);

            p.setColor(Color.argb(95,255,255,255));
            c.drawCircle(100,H-100,65,p);
            c.drawCircle(W-95,H-95,58,p);
            c.drawCircle(W-185,H-175,48,p);
            c.drawCircle(W-270,H-115,45,p);
            p.setColor(Color.WHITE);p.setTextSize(26);
            c.drawText("◀",68,H-92,p);c.drawText("▶",112,H-92,p);
            c.drawText("⚽",W-112,H-87,p);c.drawText("↑",W-198,H-165,p);
            c.drawText("P",W-285,H-105,p);
        }

        void drawTeam(Canvas c,ArrayList<Player> team,int color){
            for(int i=0;i<team.size();i++){
                Player q=team.get(i);float x=q.x*getWidth(),y=q.y*getHeight();
                p.setColor(color);c.drawCircle(x,y,i==team.size()-1?22:17,p);
                p.setColor(Color.WHITE);c.drawCircle(x,y-4,6,p);
            }
        }

        @Override public boolean onTouchEvent(MotionEvent e){
            float x=e.getX(),y=e.getY(),W=getWidth(),H=getHeight();
            if(e.getAction()==MotionEvent.ACTION_DOWN || e.getAction()==MotionEvent.ACTION_MOVE){
                l=x<145 && y>H-180;
                r=x>=80 && x<175 && y>H-180;
                u=x>W-235 && x<W-135 && y>H-225;
                kick=x>W-150 && y>H-170;
                pass=x>W-315 && x<W-225 && y>H-170;
            } else if(e.getAction()==MotionEvent.ACTION_UP){
                l=r=u=d=kick=pass=false;
            }
            return true;
        }

        void update(){
            if(l) userX-=.009f;if(r)userX+=.009f;if(u)userY-=.009f;
            if(d)userY+=.009f;
            userX=Math.max(.08f,Math.min(.75f,userX));
            userY=Math.max(.08f,Math.min(.92f,userY));

            float dist=(float)Math.hypot(ballX-userX,ballY-userY);
            if(dist<.09f && kick){ballVX=.018f;ballVY=(ballY-userY)*.12f;}
            if(dist<.09f && pass){ballVX=.010f;ballVY=(ballY-userY)*.07f;}
            ballX+=ballVX;ballY+=ballVY;ballVX*=.985f;ballVY*=.985f;
            if(ballY<.04f||ballY>.96f)ballVY=-ballVY*.75f;
            if(ballX>.985f){home++;reset();}
            if(ballX<.015f){away++;reset();}

            // move the selected blue player and simple AI
            blue.get(9).x=userX;blue.get(9).y=userY;
            for(int i=0;i<red.size()-1;i++){
                Player q=red.get(i);
                q.x+=(ballX-q.x)*.004f;q.y+=(ballY-q.y)*.004f;
            }
            invalidate();
        }

        void reset(){ballX=.5f;ballY=.5f;ballVX=ballVY=0;}

        Runnable loop=new Runnable(){public void run(){update();postDelayed(this,16);}};
        @Override protected void onAttachedToWindow(){super.onAttachedToWindow();post(loop);}
    }
}
