package com.shabakaty.tv;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.Gravity;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.time.LocalDate;
import java.time.ZoneId;

public class MainActivity extends Activity {
    private static final String API="https://api.football-data.org/v4/matches";
    private static final int GREEN=Color.rgb(32,199,119), BG=Color.rgb(4,8,6), CARD=Color.rgb(16,24,20);
    private EditText token;
    private LinearLayout list;
    private TextView status,count;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("settings",MODE_PRIVATE);
        buildUi();
        token.setText(prefs.getString("token",""));
    }

    private TextView text(String s,float size){
        TextView t=new TextView(this);
        t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size);
        t.setPadding(16,12,16,12); return t;
    }

    private Button button(String s){
        Button b=new Button(this);
        b.setText(s); b.setTextColor(Color.WHITE); b.setTextSize(14); b.setAllCaps(false);
        return b;
    }

    private void buildUi(){
        LinearLayout main=new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL); main.setPadding(12,8,12,8);
        main.setBackgroundColor(BG);

        TextView title=text("⚽  شبكتي TV V10",25);
        title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); title.setGravity(Gravity.CENTER);
        main.addView(title,new LinearLayout.LayoutParams(-1,58));

        TextView hint=text("أدخل مفتاح Football-Data ثم اختر المباريات",13);
        hint.setTextColor(Color.LTGRAY); hint.setGravity(Gravity.CENTER); main.addView(hint);

        token=new EditText(this);
        token.setHint("مفتاح API"); token.setHintTextColor(Color.GRAY); token.setTextColor(Color.WHITE);
        token.setSingleLine(true);
        token.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        main.addView(token,new LinearLayout.LayoutParams(-1,56));

        LinearLayout row=new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button save=button("حفظ المفتاح"),today=button("اليوم"),tomorrow=button("غداً");
        row.addView(save,new LinearLayout.LayoutParams(0,58,1));
        row.addView(today,new LinearLayout.LayoutParams(0,58,1));
        row.addView(tomorrow,new LinearLayout.LayoutParams(0,58,1));
        main.addView(row);

        Button live=button("🔴  المباريات المباشرة");
        main.addView(live,new LinearLayout.LayoutParams(-1,56));

        status=text("جاهز",14); status.setTextColor(GREEN); status.setGravity(Gravity.CENTER); main.addView(status);
        count=text("المباريات: 0",17); count.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        count.setGravity(Gravity.RIGHT); main.addView(count);

        ScrollView scroll=new ScrollView(this);
        list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(list); main.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        TextView foot=text("Football data provided by Football-Data.org API",10);
        foot.setTextColor(Color.GRAY); foot.setGravity(Gravity.CENTER); main.addView(foot);

        save.setOnClickListener(v->{String k=token.getText().toString().trim();
            if(k.isEmpty()){status.setText("اكتب مفتاح API أولاً");return;}
            prefs.edit().putString("token",k).apply(); status.setText("تم حفظ المفتاح ✓"); loadDay(0);});
        today.setOnClickListener(v->loadDay(0));
        tomorrow.setOnClickListener(v->loadDay(1));
        live.setOnClickListener(v->loadLive());
        setContentView(main);
    }

    private String key(){return token.getText().toString().trim();}
    private boolean checkKey(){if(key().isEmpty()){status.setText("اكتب مفتاح API أولاً");return false;}return true;}

    private void loadDay(int offset){
        if(!checkKey())return;
        LocalDate d=LocalDate.now(ZoneId.systemDefault()).plusDays(offset);
        status.setText("جاري تحميل مباريات "+(offset==0?"اليوم":"غداً")+"...");
        request(API+"?dateFrom="+d+"&dateTo="+d);
    }

    private void loadLive(){
        if(!checkKey())return;
        status.setText("جاري تحميل المباريات المباشرة...");
        request(API+"?status=LIVE");
    }

    private void request(String url){
        new Thread(()->{
            HttpURLConnection c=null;
            try{
                c=(HttpURLConnection)new URL(url).openConnection();
                c.setRequestMethod("GET"); c.setConnectTimeout(12000); c.setReadTimeout(15000);
                c.setRequestProperty("X-Auth-Token",key());
                int code=c.getResponseCode();
                InputStream in=(code>=200&&code<300)?c.getInputStream():c.getErrorStream();
                BufferedReader r=new BufferedReader(new InputStreamReader(in));
                StringBuilder sb=new StringBuilder(); String line;
                while((line=r.readLine())!=null)sb.append(line); r.close();
                String data=sb.toString(); int sc=code;
                runOnUiThread(()->showResults(data,sc));
            }catch(Exception e){
                runOnUiThread(()->{status.setText("تعذر الاتصال بالإنترنت");count.setText("المباريات: 0");});
            }finally{if(c!=null)c.disconnect();}
        }).start();
    }

    private void showResults(String data,int code){
        list.removeAllViews();
        if(code!=200){
            status.setText("خطأ من الخادم: "+code);
            list.addView(text(data.length()>300?data.substring(0,300):data,13)); return;
        }
        try{
            JSONObject root=new JSONObject(data); JSONArray arr=root.optJSONArray("matches");
            int n=arr==null?0:arr.length(); count.setText("المباريات: "+n);
            status.setText(n==0?"لا توجد مباريات بهذا الاختيار":"تم التحديث ✓");
            if(arr==null)return;
            for(int i=0;i<arr.length();i++){
                JSONObject m=arr.getJSONObject(i),home=m.optJSONObject("homeTeam"),away=m.optJSONObject("awayTeam");
                JSONObject comp=m.optJSONObject("competition"),score=m.optJSONObject("score");
                String hn=home==null?"-":home.optString("name","-"),an=away==null?"-":away.optString("name","-");
                String cn=comp==null?"":comp.optString("name",""),st=m.optString("status","");
                String dt=m.optString("utcDate",""),time=dt.length()>=16?dt.substring(11,16)+" UTC":"";
                String hs="-",as="-";
                if(score!=null){JSONObject full=score.optJSONObject("fullTime");
                    if(full!=null){hs=full.isNull("home")?"-":String.valueOf(full.optInt("home"));
                        as=full.isNull("away")?"-":String.valueOf(full.optInt("away"));}}
                LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(14,12,14,12); card.setBackgroundColor(CARD);
                TextView teams=text("⚽  "+hn+"   "+hs+" - "+as+"   "+an,17);
                teams.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
                TextView league=text("🏆  "+cn,13); league.setTextColor(Color.LTGRAY);
                TextView info=text("🕒  "+time+"   •   "+statusArabic(st),13); info.setTextColor(GREEN);
                card.addView(teams); card.addView(league); card.addView(info);
                LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT);
                p.setMargins(0,5,0,5); list.addView(card,p);
            }
        }catch(Exception e){status.setText("تعذر قراءة بيانات المباريات");}
    }

    private String statusArabic(String s){
        if("FINISHED".equals(s))return "منتهية";
        if("IN_PLAY".equals(s))return "جارية";
        if("PAUSED".equals(s))return "استراحة";
        if("POSTPONED".equals(s))return "مؤجلة";
        if("CANCELLED".equals(s))return "ملغاة";
        if("SUSPENDED".equals(s))return "متوقفة";
        return "قادمة";
    }
}
