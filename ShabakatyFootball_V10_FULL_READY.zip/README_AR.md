# شبكتي لكرة القدم V10

هذا مشروع Android كامل وجاهز للبناء بواسطة GitHub Actions.

## ملاحظة مهمة
إذا رفعت محتويات هذا المشروع إلى جذر مستودع GitHub، شغّل:
Actions → Build Shabakaty Football V10 APK → Run workflow

بعد نجاح البناء ستجد APK داخل Artifacts باسم:
ShabakatyFootball-V10-APK

مفتاح Football-Data API يُدخل من داخل التطبيق ولا يُحفظ داخل المشروع.
