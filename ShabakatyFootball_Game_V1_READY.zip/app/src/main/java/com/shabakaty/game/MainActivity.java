package com.shabakaty.game;
import android.app.*; import android.os.*; import android.graphics.*; import android.view.*; import android.content.*;
public class MainActivity extends Activity {
 public void onCreate(Bundle b){super.onCreate(b);getWindow().setFlags(1024,1024);setContentView(new G(this));}
 static class G extends View{
  Paint p=new Paint(1); float x,y,bx,by,vx,vy; boolean l,r,k,init;
  G(Context c){super(c);p.setTypeface(Typeface.DEFAULT_BOLD);}
  protected void onDraw(Canvas c){int w=getWidth(),h=getHeight();p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(25,125,45));c.drawRect(0,0,w,h,p);
   if(!init){x=w*.25f;y=h*.55f;bx=w*.5f;by=h*.55f;init=true;}
   p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(5);p.setColor(Color.WHITE);c.drawRect(30,55,w-30,h-35,p);c.drawLine(w/2,55,w/2,h-35,p);c.drawCircle(w/2,(h+20)/2,70,p);
   p.setStyle(Paint.Style.FILL);p.setColor(Color.BLUE);c.drawCircle(x,y,28,p);p.setColor(Color.RED);c.drawCircle(w*.72f,h*.5f,28,p);p.setColor(Color.WHITE);c.drawCircle(bx,by,14,p);
   if(l)x-=7;if(r)x+=7;x=Math.max(50,Math.min(w-50,x));bx+=vx;by+=vy;vx*=.985;vy*=.985;
   if(bx<45||bx>w-45){vx=-vx*.8f;bx=Math.max(45,Math.min(w-45,bx));}if(by<75||by>h-55){vy=-vy*.8f;by=Math.max(75,Math.min(h-55,by));}
   if(k){float dx=bx-x,dy=by-y,d=(float)Math.hypot(dx,dy);if(d<80){if(d<1)d=1;vx=dx/d*15;vy=dy/d*15;}k=false;}
   p.setColor(Color.argb(180,0,0,0));c.drawRect(w/2-120,5,w/2+120,45,p);p.setColor(Color.WHITE);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(22);c.drawText("شبكتي ⚽  0 - 0  الخصم",w/2,33,p);
   p.setColor(Color.argb(170,255,255,255));c.drawCircle(80,h-82,48,p);c.drawCircle(185,h-82,48,p);c.drawCircle(w-90,h-82,58,p);p.setColor(Color.DKGRAY);p.setTextSize(25);c.drawText("←",80,h-74,p);c.drawText("→",185,h-74,p);p.setTextSize(18);c.drawText("تسديد",w-90,h-76,p);invalidate();
  }
  public boolean onTouchEvent(MotionEvent e){float X=e.getX(),Y=e.getY();int a=e.getActionMasked();if(a==0||a==5){if(Y>getHeight()-155){if(X<130)l=true;else if(X<240)r=true;else if(X>getWidth()-175)k=true;}return true;}if(a==1||a==6||a==3){l=r=false;return true;}return true;}
 }
}
