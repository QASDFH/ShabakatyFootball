package com.shabakaty.game;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import java.util.*;

public class MainActivity extends Activity {
  public void onCreate(Bundle b){super.onCreate(b); getWindow().setFlags(1024,1024); setContentView(new FootballView());}
  class FootballView extends View {
    Paint p=new Paint(1); Random rnd=new Random(); float bx,by,vx=0,vy=0; int scoreA=0,scoreB=0; long start;
    String[] blue={"Alisson","Alexander-Arnold","Van Dijk","Rúben Dias","Hakimi","Rodri","Bellingham","De Bruyne","Salah","Haaland","Mbappé"};
    String[] red={"Courtois","Carvajal","Rüdiger","Militão","Theo Hernández","Valverde","Modrić","Vinícius Jr.","Kane","Lautaro","Son"};
    float[][] bp=new float[11][2], rp=new float[11][2];
    public FootballView(){super(MainActivity.this); start=System.currentTimeMillis(); reset();}
    void reset(){bx=0;by=0;vx=0;vy=0; for(int i=0;i<11;i++){bp[i][0]=.18f+(i%5)*.08f; bp[i][1]=.18f+(i/5)*.32f; rp[i][0]=.82f-(i%5)*.08f; rp[i][1]=.18f+(i/5)*.32f;}}
    protected void onDraw(Canvas c){
      float w=getWidth(),h=getHeight(); p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(20,125,55)); c.drawRect(0,0,w,h,p);
      p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4); p.setColor(Color.WHITE);
      c.drawRect(25,25,w-25,h-25,p); c.drawLine(w/2,25,w/2,h-25,p); c.drawCircle(w/2,h/2,75,p);
      c.drawRect(25,h*.30f,130,h*.70f,p); c.drawRect(w-130,h*.30f,w-25,h*.70f,p);
      p.setStyle(Paint.Style.FILL);
      // top HUD
      p.setColor(Color.argb(220,15,15,20)); c.drawRoundRect(w*.37f,8,w*.63f,58,18,18,p);
      text(c,"LIVERPOOL  "+scoreA+"  -  "+scoreB+"  REAL MADRID",w/2,40,20,Color.WHITE,true);
      long sec=Math.max(0,(System.currentTimeMillis()-start)/1000); text(c,"90:00",w/2,82,16,Color.WHITE,true);
      for(int i=0;i<11;i++){player(c,bp[i][0]*w,bp[i][1]*h,Color.rgb(35,90,220),blue[i],i==8);}
      for(int i=0;i<11;i++){player(c,rp[i][0]*w,rp[i][1]*h,Color.rgb(210,35,45),red[i],false);}
      c.drawCircle(w*.50f+bx,w*.50f+by,11,p); p.setColor(Color.WHITE); c.drawCircle(w/2+bx,h/2+by,10,p);
      // controls
      p.setColor(Color.argb(150,0,0,0)); c.drawCircle(85,h-85,58,p); c.drawCircle(w-145,h-80,45,p); c.drawCircle(w-65,h-125,45,p);
      text(c,"◀",45,h-77,25,Color.WHITE,true); text(c,"▶",125,h-77,25,Color.WHITE,true); text(c,"PASS",w-145,h-75,13,Color.WHITE,true); text(c,"SHOOT",w-65,h-120,12,Color.WHITE,true);
      text(c,"REAL PLAYERS • V6",w/2,h-18,12,Color.WHITE,true);
      invalidate();
    }
    void player(Canvas c,float x,float y,int col,String name,boolean star){
      p.setColor(Color.argb(220,0,0,0)); c.drawCircle(x+2,y+3,18,p);
      p.setColor(col); c.drawCircle(x,y,18,p); p.setStyle(Paint.Style.STROKE); p.setColor(Color.WHITE); p.setStrokeWidth(2); c.drawCircle(x,y,18,p); p.setStyle(Paint.Style.FILL);
      text(c,name,x,y+32,10,Color.WHITE,star);
    }
    void text(Canvas c,String s,float x,float y,float size,int color,boolean bold){p.setTextSize(size);p.setColor(color);p.setTypeface(bold?Typeface.DEFAULT_BOLD:Typeface.DEFAULT);p.setTextAlign(Paint.Align.CENTER);c.drawText(s,x,y,p);}
    public boolean onTouchEvent(android.view.MotionEvent e){
      if(e.getAction()==1){float x=e.getX(), y=e.getY(); float w=getWidth(),h=getHeight();
        if(x>w-190 && y>h-150){vx=(x>w-100?10:5);vy=(y>h-105?0:-7);}
        else if(x<180 && y>h-170){vx=(x<90?-8:8);}
        else {bx=(x-w/2)*.25f;by=(y-h/2)*.25f;}
        if(x>w-110&&y>h-180){scoreA++; reset();}
        return true;} return true;
    }
  }
}